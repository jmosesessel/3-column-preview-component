import "./App.css";
import MainPage from "./view/MainPage";

function App() {
	return (
		<div className="App">
			<MainPage></MainPage>
		</div>
	);
}

export default App;
